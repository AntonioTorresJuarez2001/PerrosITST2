package com.example.perrositst;

import static android.Manifest.permission.CALL_PHONE;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.PackageManagerCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class DetailActivity extends AppCompatActivity {
    public static final String PET_KEY = "pet";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);


        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            Log.d("DetailActivity", "Extras are not null");
          final   Pet pet = extras.getParcelable(PET_KEY);
            if (pet != null) {
                Log.d("DetailActivity", "Received pet: " + pet.getName());
                TextView petName = findViewById(R.id.activity_detail_pet_name);
                TextView petDescription = findViewById(R.id.activity_detail_pet_description);
                TextView ownerName = findViewById(R.id.activity_detail_owner_name);
                TextView ownerPhoneNumber = findViewById(R.id.activity_detail_owner_phone_number);
                ImageView petImage = findViewById(R.id.activity_detail_pet_image);

                petName.setText(pet.getName());
                petDescription.setText(pet.getDescription());
                ownerName.setText(pet.getOwnerName());
                ownerPhoneNumber.setText(pet.getPhoneNumber());
                petImage.setImageDrawable(ContextCompat.getDrawable(this, pet.getImageId()));

                FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab1);
            } else {
                Log.e("DetailActivity", "Pet is null");
                // Manejar el caso donde 'pet' es nulo
            }
        } else {
            Log.e("DetailActivity", "Extras are null");
            // Manejar el caso donde 'extras' es nulo
        }
    }

    //// private void makeCall(String ownerPhoneNumber) {
    ////Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("Telfono: " + ownerPhoneNumber));
    //     if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
    // if(checkSelfPermission(CALL_PHONE) == PackageManager.PERMISSION_GRANTED){
        //             startActivity(intent);

    //      }else {
    //         final String[] permissions = new String[]{CALL_PHONE};
    //          requestPermissions(permissions, CALL_PHONE_REQUEST_CODE);}

    //      }
    //  }
    // }

}
