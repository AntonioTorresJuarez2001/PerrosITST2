package com.example.perrositst;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.Toolbar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        RecyclerView petRecycler = (RecyclerView) findViewById(R.id.activity_main_pet_recycler);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        petRecycler.setLayoutManager(linearLayoutManager);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        petRecycler.setLayoutManager(gridLayoutManager);

        ArrayList<Pet> petList = new ArrayList<>();
        petList.add(new Pet("Chester", getString(R.string.pet_description), "Actual Dueño: Ing Karla ITST", "555-55-55", R.drawable.chester));
        petList.add(new Pet("Chino", getString(R.string.pet_description), "Actual Dueño: Ing Karla ITST", "555-55-55", R.drawable.chino));
        petList.add(new Pet("Choco", getString(R.string.pet_description), "Actual Dueño: Ing Karla ITST", "555-55-55", R.drawable.choco));
        petList.add(new Pet("Chorejas", getString(R.string.pet_description), "Actual Dueño: Ing Karla ITST", "555-55-55", R.drawable.chorejas));
        petList.add(new Pet("Clarita", getString(R.string.pet_description), "Actual Dueño: Ing Karla ITST", "555-55-55", R.drawable.clarita));
        petList.add(new Pet("Negrito", getString(R.string.pet_description), "Claudia", "555-55-55", R.drawable.negrita));
        petList.add(new Pet("Chester", getString(R.string.pet_description), "Actual Dueño: Ing Karla ITST", "555-55-55", R.drawable.chester));
        petList.add(new Pet("Chino", getString(R.string.pet_description), "Actual Dueño: Ing Karla ITST", "555-55-55", R.drawable.chino));
        petList.add(new Pet("Choco", getString(R.string.pet_description), "Actual Dueño: Ing Karla ITST", "555-55-55", R.drawable.choco));
        petList.add(new Pet("Chorejas", getString(R.string.pet_description), "Actual Dueño: Ing Karla ITST", "555-55-55", R.drawable.chorejas));
        petList.add(new Pet("Clarita", getString(R.string.pet_description), "Actual Dueño: Ing Karla ITST", "555-55-55", R.drawable.clarita));
        petList.add(new Pet("Negrito", getString(R.string.pet_description), "Claudia", "555-55-55", R.drawable.negrita));



        PetAdapter petAdapter = new PetAdapter(this, petList);
        petRecycler.setAdapter(petAdapter);

        petAdapter.setOnPetClickListener(new PetAdapter.OnPetClickListener() {
            @Override
            public void onPetClick(Pet pet) {
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra(DetailActivity.PET_KEY, pet);

                startActivity(intent);
            }
        });

    }
}